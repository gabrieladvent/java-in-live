/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asa;

/**
 *
 * @author Ribka Restu
 */
public class Test {
    private String kode_barang;
    private String nama_barang;
    private String harga_barang;
    private String stok_barang;

//    /**
//     * @return the kode_karyawan
//     */
//    public String getKode_karyawan() {
//        return kode_karyawan;
//    }
//
//    /**
//     * @param kode_karyawan the kode_karyawan to set
//     */
//    public void setKode_karyawan(String kode_karyawan) {
//        this.kode_karyawan = kode_karyawan;
//    }
//
//    /**
//     * @return the nama_karyawan
//     */
//    public String getNama_karyawan() {
//        return nama_karyawan;
//    }
//
//    /**
//     * @param nama_karyawan the nama_karyawan to set
//     */
//    public void setNama_karyawan(String nama_karyawan) {
//        this.nama_karyawan = nama_karyawan;
//    }
//
//    /**
//     * @return the no_telp_karyawan
//     */
//    public String getNo_telp_karyawan() {
//        return no_telp_karyawan;
//    }
//
//    /**
//     * @param no_telp_karyawan the no_telp_karyawan to set
//     */
//    public void setNo_telp_karyawan(String no_telp_karyawan) {
//        this.no_telp_karyawan = no_telp_karyawan;
//    }

    /**
     * @return the kode_barang
     */
    public String getKode_barang() {
        return kode_barang;
    }

    /**
     * @param kode_barang the kode_barang to set
     */
    public void setKode_barang(String kode_barang) {
        this.kode_barang = kode_barang;
    }

    /**
     * @return the nama_barang
     */
    public String getNama_barang() {
        return nama_barang;
    }

    /**
     * @param nama_barang the nama_barang to set
     */
    public void setNama_barang(String nama_barang) {
        this.nama_barang = nama_barang;
    }

    /**
     * @return the harga_barang
     */
    public String getHarga_barang() {
        return harga_barang;
    }

    /**
     * @param harga_barang the harga_barang to set
     */
    public void setHarga_barang(String harga_barang) {
        this.harga_barang = harga_barang;
    }

    /**
     * @return the stok_barang
     */
    public String getStok_barang() {
        return stok_barang;
    }

    /**
     * @param stok_barang the stok_barang to set
     */
    public void setStok_barang(String stok_barang) {
        this.stok_barang = stok_barang;
    }
}
