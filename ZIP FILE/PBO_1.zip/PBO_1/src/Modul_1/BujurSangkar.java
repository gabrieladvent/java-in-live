/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_1;
import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class BujurSangkar {
    Scanner inp = new Scanner(System.in);
        int sisi;
        double luas;

BujurSangkar() {};
        public double luas(){
        luas = sisi * sisi;
        return luas;
}
}