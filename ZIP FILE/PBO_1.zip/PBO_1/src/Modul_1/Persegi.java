/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_1;

/**
 *
 * @author ACER
 */
public class Persegi {
        int panj;
        int lebar;
        double luas;

Persegi(){};
public double luas() {
        luas=panj*lebar;
        return luas;
}
}
