/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_1;

/**
 *
 * @author ACER
 */
public class Lingkaran {
        double r;
        double luas;
        final double PHI=3.14;
Lingkaran() {};

public void luas(){
        r=7;
        luas=PHI*r*r;
        System.out.println("Luas lingkaran dengan jari="+r+" adalah : "+luas);
}
}