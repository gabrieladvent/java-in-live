/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_1;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class NewClass {
    public static void main(String[] args) {
        Scanner gab = new Scanner(System.in);
        System.out.println("dss");
        System.out.print("nila\tia: ");
        double a = gab.nextDouble();
        System.out.println("nilai a" + a);
    }
}
