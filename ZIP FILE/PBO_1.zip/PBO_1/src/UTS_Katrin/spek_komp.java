/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS_Katrin;

/**
 *
 * @author ACER
 */
public class spek_komp {
        private String nama;
        private String ram;
        private String ddr;
        private String prosesor;
        
spek_komp(){}

public String getNama(){
        return nama;
}
public void setNama(String nama){
        this.nama = nama;
}

public String getRam() {
        return ram;
}
public void setRam(String ram) {
        this.ram = ram;
}

public String getDdr() {
        return ddr;
}
public void setDdr(String ddr) {
        this.ddr = ddr;
}

public String getProsesor() {
        return prosesor;
}
public void setProsesor(String prosesor) {
        this.prosesor = prosesor;
}
}
