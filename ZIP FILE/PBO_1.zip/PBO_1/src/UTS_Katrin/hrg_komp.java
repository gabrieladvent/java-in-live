/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS_Katrin;

/**
 *
 * @author ACER
 */
public class hrg_komp {
        private int hrg;
        
public hrg_komp(){}

public int getHrg() {
        return hrg;
}
public void setHrg(int hrg) {
        this.hrg = hrg;
}
}
