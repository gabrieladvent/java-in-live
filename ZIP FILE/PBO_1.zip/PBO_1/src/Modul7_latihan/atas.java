/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul7_latihan;

/**
 *
 * @author ACER
 */
public class atas {
    int i = 5;
    int j = 2;
    atas() {} //constructor
void cetak1() {
System.out.println("ini kelas utama\nAda di class ATAS ..");
    System.out.println("i: "+i);
    System.out.println("j: "+j);
    System.out.println("");
}
  
}
