/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_8;

/**
 *
 * @author ACER
 */
public class Persegi extends BangunDatar{
     double p, l;
    
public Persegi (double p, double l){
        this.p = p; this.l = l;
}
    @Override
double hitungKel(){
        return 2 * (p + l);
}
    @Override
double hitungLuas(){
    return p * l;
}
@Override
String Status(){
        return "Persegi";
}
}
