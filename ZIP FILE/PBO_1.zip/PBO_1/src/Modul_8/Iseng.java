/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_8;

/**
 *
 * @author ACER
 */
public class Iseng {
    public static void main(String[] args) {
 Hewan kewan = new Hewan();
 kewan.suara();
        System.out.println("");
 kewan = new Anjing();
 kewan.suara();
        System.out.println("");
 kewan = new Kucing();
 kewan.suara();
        System.out.println("");
 kewan = new Bebek();
 kewan.suara();
        System.out.println("");
  kewan = new Harimau();
  kewan.suara();
}
}
