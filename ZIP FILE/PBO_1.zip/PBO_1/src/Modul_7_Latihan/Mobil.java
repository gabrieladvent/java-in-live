/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_7_Latihan;

/**
 *
 * @author ACER
 */
public class Mobil {
        private String warna;
        private String merk;
    
Mobil(){}
    
public String getMerk(){
        return merk;
}
public void setMerk(String merk){
        this.merk = merk;
}

public String getWarna(){
        return warna;
}
public void setWarna(String warna){
        this.warna = warna;    
}
}