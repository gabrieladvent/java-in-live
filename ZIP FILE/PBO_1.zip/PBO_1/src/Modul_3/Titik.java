/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul_3;

/**
 *
 * @author ACER
 */
public class Titik {
    private int x, y;

public Titik (int x, int y) //constructor Titik
{
 this.x = x;
 this.y = y;
}
public void setX (int x) {
 this.x= x;
}
public void setY(int y) {
 this.y= y;
}
public int getX () {
 return x;
}
public int getY () {
 return y;
}
}
