package integer;

public class LinkedList {

    private int size;
    private ListNode head;
    private String nama;
    
    public LinkedList() {
        head = new ListNode();
        head.setNext(head);
        head.setPrev(head);
        size = 0;
    }

    public LinkedList(String s) {
        nama = s;
    }

    public int size() {
        return size;
    }
    
    private void addBefore(int e, ListNode node){
        ListNode baru = new ListNode(e);
        baru.setNext(node);
        baru.setPrev(node.getPrev());
        node.getPrev().setNext(baru);
        node.setPrev(baru);
        size++;
    }
    
    private int remove(ListNode node){
        node.getNext().setPrev(node.getPrev());
        node.getPrev().setNext(node.getNext());
        node.setNext(null);
        node.setPrev(null);
        size--;
        return node.getElement();
    }
    
    public void addFirst(int e){
        addBefore(e, head.getNext());
    }
    
    public void addLast(int e){
        addBefore(e, head);
    }
    
    public int removeFirst(){
        return remove(head.getNext());
    }
    
    public int removeLast(){
        return remove(head.getPrev());
    }
    
    public ListNode baca(int index) {
        ListNode baca = head.getNext();
        for (int i = 0; i < index; i++) {
            baca = baca.getNext();
        }
        return baca;
    }
    
    @Override
    public String toString(){
        String s = "";
        for (int i = 0; i < size; i++) {
            if (i == size - 1) {
                s = s + baca(i).getElement();
            } else {
                s = s + baca(i).getElement() + ", ";
            }
        }
        return "[" + s + "]";
    }
    
    public boolean isEmpty(){
        return size == 0;
    }
}
