package integer;

import java.util.Arrays;

public class SDL11 {

    public static void main(String[] args) {
        int[] ayam = new int[2];
        System.out.println(Arrays.toString(ayam));
    }
}
