package integer;

public class StackArray<E> {
    private E[] element;
    private int front;
    private int size;

    public StackArray(int length) {
        element = (E[]) new Object[length];
        front = -1;
        size = 0;
    }

    public StackArray() {
    }
    
    public boolean push(E element){
        try {
            front++;
            this.element[front] = element;
            size++;
            return true;
        } catch (ArrayIndexOutOfBoundsException e) {
            return false;
        }
    }
    
    public E pop(){
        E pop = element[front];
        element[front] = null;
        front--;
        size--;
        return pop;
    }
    
    public boolean isEmpty(){
        return size == 0;
    }

    public int size() {
        return size;
    }
    
    @Override
    public String toString(){
        String s = "";
        for (int i = front; i >= 0; i--) {
            if (i > 0) {
                s = s + element[i].toString() + ", ";
            } else {
                s = s + element[i].toString();
            }
        }
        return "[" + s + "]";
    }
}
