package integer;

public class ListNode {

    private int element;
    private ListNode next, prev;

    public ListNode() {
    }

    public ListNode(int d) {
        this.element = d;
    }

    public ListNode(int d, ListNode n) {
        this.element = d;
        this.next = n;
    }

    public int getElement() {
        return element;
    }

    public void setElement(int element) {
        this.element = element;
    }

    public ListNode getNext() {
        return next;
    }

    public void setNext(ListNode next) {
        this.next = next;
    }

    public ListNode getPrev() {
        return prev;
    }

    public void setPrev(ListNode prev) {
        this.prev = prev;
    }
}
