package integer;

import java.util.EmptyStackException;

public class StackLinkedList {
    private LinkedList tumpukan;

    public StackLinkedList() {
        tumpukan = new LinkedList();
    }
    
    public void push(int elemen){
        tumpukan.addFirst(elemen);
    }
    
    public int pop(){
        if (tumpukan.isEmpty()) {
            throw new EmptyStackException();
        }
        else {
            return tumpukan.removeFirst();
        }
    }
    
    public int size(){
        return tumpukan.size();
    }
    
    public boolean isEmpty(){
        return tumpukan.isEmpty();
    }
    
    @Override
    public String toString(){
        return tumpukan.toString();
    }
}
