package integer;

public class QueueArray {

    private int[] element;
    private int front;
    private int rear;
    private int size;

    public QueueArray(int length) {
        element = new int[length];
        front = -1;
        rear = -1;
        size = 0;
    }

    public QueueArray() {
        
    }

    public boolean enqueue(int element) {
        if (size == this.element.length) {
            throw new IndexOutOfBoundsException("queue is full");
        }
        try {
            if (size == 0) {
                front = 0;
            }
            if (rear == (this.element.length - 1) && this.element[0] == 0) {
                rear = -1;
            }
            rear++;
            this.element[rear] = element;
            size++;
            return true;
        } catch (ArrayIndexOutOfBoundsException e) {
            rear--;
            return false;
        }
    }

    public int dequeue() {
        int dequeue = element[front];
        element[front] = 0;
        if (front == (this.element.length - 1)) {
            front = -1;
        }
        front++;
        size--;
        return dequeue;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    @Override
    public String toString() {
        String s = "";
        int i = 0;
        int awal = front;
        while (i < size) {
            if (i == size - 1) {
                s = s + String.valueOf(element[awal]);
            } else {
                s = s + String.valueOf(element[awal]) + ", ";
            }
            awal++;
            if (awal == (this.element.length)) {
                awal = 0;
            }
            i++;
        }
        return "[" + s + "]";
    }
}
