package object;

public class ListNode<E> {

    private E element;
    private ListNode<E> next, prev;

    public ListNode() {
    }

    public ListNode(E d) {
        this.element = d;
    }

    public ListNode(E d, ListNode n) {
        this.element = d;
        this.next = n;
    }

    public E getElement() {
        return element;
    }

    public void setElement(E element) {
        this.element = element;
    }

    public ListNode<E> getNext() {
        return next;
    }

    public void setNext(ListNode<E> next) {
        this.next = next;
    }

    public ListNode<E> getPrev() {
        return prev;
    }

    public void setPrev(ListNode<E> prev) {
        this.prev = prev;
    }
}
