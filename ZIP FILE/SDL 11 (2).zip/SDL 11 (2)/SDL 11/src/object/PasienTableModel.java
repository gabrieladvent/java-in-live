package object;

import java.util.*;
import javax.swing.table.AbstractTableModel;

public class PasienTableModel extends AbstractTableModel {

    private QueueLinkedList<Pasien> pasien = new QueueLinkedList();

    public PasienTableModel(QueueLinkedList pasien) {
        this.pasien = pasien;
    }

    @Override
    public int getRowCount() {
        return pasien.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Pasien data = pasien.baca(rowIndex);
        switch (columnIndex) {
            case 0:
                return data.getNoUrut();
            case 1:
                return data.getNama();
            case 2:
                return data.getUmur();
            case 3:
                return data.getSex();
            case 4:
                return data.getAlamat();
            case 5:
                return data.getKeluhan();
            default:
                return "";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "NO";
            case 1:
                return "NAMA";
            case 2:
                return "UMUR";
            case 3:
                return "SEX";
            case 4: 
                return "ALAMAT";
            case 5:
                return "KELUHAN";
            default:
                return "";
        }
    }

}
