package object;

public class LinkedList<E> {

    private int size;
    private ListNode<E> head;
    private String nama;
    
    public LinkedList() {
        head = new ListNode();
        head.setNext(head);
        head.setPrev(head);
        size = 0;
    }

    public LinkedList(String s) {
        nama = s;
    }

    public int size() {
        return size;
    }
    
    private void addBefore(E e, ListNode<E> node){
        ListNode<E> baru = new ListNode(e);
        baru.setNext(node);
        baru.setPrev(node.getPrev());
        node.getPrev().setNext(baru);
        node.setPrev(baru);
        size++;
    }
    
    private E remove(ListNode<E> node){
        node.getNext().setPrev(node.getPrev());
        node.getPrev().setNext(node.getNext());
        node.setNext(null);
        node.setPrev(null);
        size--;
        return node.getElement();
    }
    
    public void addFirst(E e){
        addBefore(e, head.getNext());
    }
    
    public void addLast(E e){
        addBefore(e, head);
    }
    
    public E removeFirst(){
        return remove(head.getNext());
    }
    
    public E removeLast(){
        return remove(head.getPrev());
    }
    
    public ListNode<E> baca(int index) {
        ListNode<E> baca = head.getNext();
        for (int i = 0; i < index; i++) {
            baca = baca.getNext();
        }
        return baca;
    }
    
    @Override
    public String toString(){
        String s = "";
        for (int i = 0; i < size; i++) {
            if (i == size - 1) {
                s = s + baca(i).getElement();
            } else {
                s = s + baca(i).getElement() + ", ";
            }
        }
        return "[" + s + "]";
    }
    
    public boolean isEmpty(){
        return size == 0;
    }
}
