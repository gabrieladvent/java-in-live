package object;

public class Pasien {
    private String nama;
    private int umur;
    private String sex;
    private String alamat;
    private String keluhan;
    private String noUrut;
    private String kategori;

    public Pasien(String nama, int umur, String sex, String alamat, String keluhan) {
        this.nama = nama;
        this.umur = umur;
        this.sex = sex;
        this.alamat = alamat;
        this.keluhan = keluhan;
    }

    public Pasien() {
    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getNoUrut() {
        return noUrut;
    }

    public void setNoUrut(String noUrut) {
        this.noUrut = noUrut;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getKeluhan() {
        return keluhan;
    }

    public void setKeluhan(String keluhan) {
        this.keluhan = keluhan;
    }
}
