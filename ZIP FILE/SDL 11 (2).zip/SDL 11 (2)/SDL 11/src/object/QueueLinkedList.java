package object;

public class QueueLinkedList<E> {
     private LinkedList<E> tumpukan;
     
     public QueueLinkedList(){
         tumpukan = new LinkedList<>();
     }
     
     public void enqueue(E element){
         tumpukan.addLast(element);
     }
     
     public E dequeue(){
         if (tumpukan.isEmpty()) {
            throw new Error("empty queue, please enqueue");
        }
        else {
            return tumpukan.removeFirst();
        }
     }
     
     public int size(){
        return tumpukan.size();
    }
    
    public boolean isEmpty(){
        return tumpukan.isEmpty();
    }
    
    @Override
    public String toString(){
        return tumpukan.toString();
    }

    public E baca(int i) {
        return tumpukan.baca(i).getElement();
    }
}
