/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contoh;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Tak Bertuan
 */
public class graf {

    /* Representation of a vertex */
    static class Node {
        int val;
        List<Node> children; // Edges in the graph to other vertices

        public Node() {
            children = new ArrayList<>();
        }
    }

    /**
     * Runs Breadth-First Search (BFS) on the graph starting at Node start
     * @param start is the Node at which we are starting our algorithm
     * @param end is the value we are searching for in the graph
     * @return true if there is a path from Node start to a Node with value end,
     *         false otherwise
     */
    public boolean bfs(Node start, int end) {
        HashSet<Node> visited = new HashSet<>();
        Queue<Node> adjacent = new LinkedList<>();
        adjacent.add(start);

        // Loop through all adjacent nodes
        while (!adjacent.isEmpty()) {
            Node current = adjacent.remove();
            if (current.val == end) {
                return true;
            }
            for (int i = 0; i < current.children.size(); i++) {
                Node adjacentNode = current.children.get(i);
                if (!visited.contains(adjacentNode)) {
                    adjacent.add(current.children.get(i));
                }
            }
            visited.add(current);
        }

        return false;
    }
    public static void main(String[] args) {
        
    }
}
