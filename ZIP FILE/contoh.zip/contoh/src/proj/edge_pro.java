/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj;

/**
 *
 * @author Tak Bertuan
 */
public class edge_pro {
    int vertex;
    int bobot;
    
public edge_pro(int vertex, int bobot){
    this.vertex = vertex; 
    this.bobot = bobot; 
}
	
@Override
public String toString(){
    return "("+graph_pro1.kota [vertex]+ ", " + bobot + ")";
}  
}
