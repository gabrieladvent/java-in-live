/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author Tak Bertuan
 */
public class graph_pro1 {
    private int noVertex;
    private LinkedList <edge_pro> adj [];
    static String [] kota;
    
public graph_pro1 (int noVertex, String [] kota){
    this.noVertex = noVertex;
    adj = new LinkedList [noVertex];
    for (int i = 0; i < noVertex; i++) {
        adj [i] = new LinkedList ();
    }
    this.kota = kota;
}

public void addEdge (int awal, int akhir, int bobot){
    edge_pro data = new edge_pro(akhir, bobot);
    adj [awal].add(data);
   // System.out.println("[" + awal + ", " + akhir + " = " + bobot + "]");
}
public void addEdge (char awal, char akhir, int bobot){
    edge_pro data = new edge_pro(akhir, bobot);
    adj [awal].add(data);
}

@Override
public String toString() {
    String hasil = " ";
    for (int i = 0; i < adj.length; i++) {
        hasil = hasil + kota [i] + " --> " + adj [i] + "\n";
    }
    return hasil;
}

public void show (){
    for (int i = 0; i < noVertex; i++) {
        
    }
}

static void cetakQueue(LinkedList<Integer> queue) {
    String awal = "";
    for (Integer nilai : queue) {
        awal += kota [nilai] + "-->";
    }
    System.out.println(awal);
}
public void BFS (int awal, int akhir){
    int [] bobotKota = new int [noVertex];
    String [] jalan = new String [noVertex];
    boolean kunjungan [] = new boolean [noVertex];
    LinkedList <Integer> queue = new LinkedList <Integer> ();
    
    kunjungan [awal] = true;
    queue.add(awal);
    bobotKota [awal] = 0;
    jalan [awal] = kota [awal];
    while (queue.size() != 0){
        System.out.print(kota [awal] + ": ");
        cetakQueue(queue);
        awal = queue.poll();
        if (awal == akhir) {
            System.out.println("Anda Sudah sampai tujuan");
            break;
        } else {
            Iterator <edge_pro> iterator = adj [awal].listIterator();
            int data;
            while (iterator.hasNext ()){
                edge_pro edge = iterator.next();
                data = edge.vertex;
                if (!kunjungan [data]) {
                    bobotKota [data] = bobotKota [awal] + edge.bobot;
                    jalan [data] = jalan [awal] + "--> " + kota [data];
                    kunjungan [data] = true;
                    queue.add(data);
                }
            }
        }
    }
    System.out.print(kota [awal] + ": ");
    cetakQueue(queue);
    System.out.println("\n");
    System.out.println("Rute: " + jalan [awal]);
    System.out.println("Total Jarak: " + bobotKota [awal]);
}
}
