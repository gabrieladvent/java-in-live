/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj;
import java.util.Scanner;
/**
 *
 * @author Tak Bertuan
 */
public class main_pro1 {
public static void main(String[] args) {
    Scanner inp = new Scanner (System.in);
    String[] kota = {"Tajem", "Janti", "Paingan", "Babarsari", "Cangkringan" +
                     "Seturan", "Kledokan", "Gowok", "Nologaten", "Kusumanegara" +
                     "Alun-Alun Kidul", "Taman Sari", "Condong Catur", "Gejayan", "Mrican" +
                     "Lempuyangan", "Alun-Alun Utara", "Kaliurang", "Tugu Jogja", "Malioboro"};
    graph_pro1 mapJogja = new graph_pro1(20, kota);
    
    
    mapJogja.addEdge(0, 1, 7);
    mapJogja.addEdge(0, 2, 2);
    mapJogja.addEdge(0, 4, 13);
    
    mapJogja.addEdge(1, 2, 5);
    mapJogja.addEdge(1, 3, 1);
    mapJogja.addEdge(1, 7, 2);
    mapJogja.addEdge(1, 9, 6);
    
    mapJogja.addEdge(2, 3, 5);
    mapJogja.addEdge(2, 5, 3);
    mapJogja.addEdge(2, 12, 5);
    mapJogja.addEdge(2, 4, 15);
    
    mapJogja.addEdge(3, 5, 1);
    mapJogja.addEdge(3, 6, 1);
    
    mapJogja.addEdge(4, 12, 16);
    mapJogja.addEdge(4, 17, 16);
    
    mapJogja.addEdge(5, 6, 1);
    mapJogja.addEdge(5, 8, 2);
    
    mapJogja.addEdge(6, 7, 3);
    
    mapJogja.addEdge(7, 14, 2);
    mapJogja.addEdge(7, 8, 2);
    mapJogja.addEdge(7, 9, 4);
    
    mapJogja.addEdge(8, 14, 3);
    mapJogja.addEdge(8, 13, 4);
    mapJogja.addEdge(8, 12, 4);
    
    mapJogja.addEdge(9, 10, 4);
    
    mapJogja.addEdge(10, 11, 1);
    mapJogja.addEdge(10, 16, 2);
    mapJogja.addEdge(10, 19, 3);
    
    mapJogja.addEdge(11, 16, 2);
    
    mapJogja.addEdge(12, 13, 1);
    mapJogja.addEdge(12, 17, 3);
    
    mapJogja.addEdge(13, 14, 1);
    mapJogja.addEdge(13, 17, 3);
    mapJogja.addEdge(13, 18, 6);
    
    mapJogja.addEdge(14, 15, 4);
    
    mapJogja.addEdge(15, 18, 2);
    mapJogja.addEdge(15, 19, 2);
    mapJogja.addEdge(15, 16, 3);
    
    mapJogja.addEdge(16, 19, 1);
    
    mapJogja.addEdge(17, 18, 10);
    
    mapJogja.addEdge(18, 19, 2);
    
    mapJogja.toString();
    System.out.print("Masukan Titik Awal: ");
    int awal = inp.nextInt();
    System.out.print("Masukan Titik Tujuan: ");
    int akhir = inp.nextInt();
    
    mapJogja.BFS(awal, akhir);
}
}
