/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proj;

/**
 *
 * @author Tak Bertuan
 */
public class main_pro {
public static void main(String[] args) {
    graph_pro gr = new graph_pro();
    gr.addVertex('A'); gr.addVertex('B'); gr.addVertex('C'); gr.addVertex('D'); 
    gr.addVertex('E'); gr.addVertex('F'); gr.addVertex('G'); gr.addVertex('H');
    gr.addVertex('I'); gr.addVertex('J'); gr.addVertex('K'); gr.addVertex('L');
    gr.addVertex('M'); gr.addVertex('N'); gr.addVertex('O'); gr.addVertex('P');
    gr.addVertex('Q'); gr.addVertex('R'); gr.addVertex('S'); gr.addVertex('T');
    gr.addVertex('U');
    
    gr.addEdge('A', 'B', 7);
    gr.addEdge('A', 'C', 2);
    gr.addEdge('A', 'E', 13);
    
    gr.addEdge('B', 'C', 5);
    gr.addEdge('B', 'D', 1);
    gr.addEdge('B', 'H', 2);
    gr.addEdge('B', 'J', 6);
    
    gr.addEdge('C', 'D', 5);
    gr.addEdge('C', 'F', 3);
    gr.addEdge('C', 'M', 5);
    gr.addEdge('C', 'E', 15);
    
    gr.addEdge('D', 'F', 1);
    gr.addEdge('D', 'G', 1);
    
    gr.addEdge('E', 'M', 16);
    gr.addEdge('E', 'R', 16);
    
    gr.addEdge('F', 'G', 1);
    gr.addEdge('F', 'I', 2);
    
    gr.addEdge('G', 'H', 3);
    
    gr.addEdge('G', 'O', 2);
    gr.addEdge('G', 'N', 2);
    gr.addEdge('G', 'M', 4);
    
    gr.addEdge('I', 'O', 3);
    gr.addEdge('I', 'N', 4);
    gr.addEdge('I', 'M', 4);
    
    gr.addEdge('J', 'K', 4);
    
    gr.addEdge('K', 'L', 1);
    gr.addEdge('K', 'Q', 2);
    gr.addEdge('K', 'T', 3);
    
    gr.addEdge('L', 'Q', 2);
    
    gr.addEdge('M', 'N', 1);
    gr.addEdge('M', 'R', 3);
    
    gr.addEdge('N', 'O', 1);
    gr.addEdge('N', 'R', 3);
    gr.addEdge('N', 'S', 6);
    
    gr.addEdge('O', 'P', 4);
    
    gr.addEdge('P', 'S', 2);
    gr.addEdge('P', 'T', 2);
    gr.addEdge('P', 'Q', 3);
    
    gr.addEdge('Q', 'T', 1);
    
    gr.addEdge('R', 'S', 10);
    
    gr.addEdge('S', 'T', 2);
    
    gr.showGraph();
    gr.bfs();
    
}
}
