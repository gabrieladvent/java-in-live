/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODUL_2;

/**
 *
 * @author ACER
 */
public class CelciusFahrenheit {
    public static void main(String [] args) {
        double celcius, fahrenheit;
        
        celcius = 5;
        fahrenheit = (1.8) * celcius + 32;
        
        System.out.println("Suhu 5 derajat celcius = "+fahrenheit+" derajat suhu fahrenheit");
    }
    
}
