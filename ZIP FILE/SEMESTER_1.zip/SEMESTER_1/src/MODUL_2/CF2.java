/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODUL_2;

/**
 *
 * @author ACER
 */
public class CF2 {
    public static void main(String[] args) {
        float celcius, fahrenheit;
        
        celcius = 5;
        fahrenheit = (9f/5f) * celcius + 32;
                
        System.out.println("suhu 5 derajat celcius = "+fahrenheit+" derajat fahrenheit");
    }
    
}
