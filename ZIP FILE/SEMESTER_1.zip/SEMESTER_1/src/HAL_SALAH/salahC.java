/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HAL_SALAH;

/**
 *
 * @author ACER
 */
public class salahC {
    public static void main(String [] args) {
        int nilai, hasilpangkat;
    
    nilai = 3;
    hasilpangkat = nilai * nilai;
    System.out.print("Hasil dari pangkat adalah :"+hasilpangkat);
    
    }
    
}
