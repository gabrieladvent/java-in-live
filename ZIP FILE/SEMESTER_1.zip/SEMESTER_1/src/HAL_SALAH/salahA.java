/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HAL_SALAH;

/**
 *
 * @author ACER
 */
public class salahA {
    public static void main(String[] args) {
        char a;
        
        a='d';
        System.out.println(a);
    }
    
}
