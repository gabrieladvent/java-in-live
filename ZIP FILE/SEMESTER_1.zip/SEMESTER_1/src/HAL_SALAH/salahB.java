/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HAL_SALAH;

/**
 *
 * @author ACER
 */
public class salahB {
    public static void main(String[] args) {
            int x,y,b;
            
            b = 3;
            x = 4;
            y = b * x + b;
            System.out.println("Hasil dari persamaan y adalah :"+y);
    
}
}