/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODUL_6B;

/**
 *
 * @author ACER
 */
public class coba2 {
          public static void main(String[] args) {
            int  bilangan = 1;
	    while ( bilangan < 21 ) {
		System.out.print(bilangan+ ",     ");
		bilangan = bilangan + 1;
		}
	    }

}
