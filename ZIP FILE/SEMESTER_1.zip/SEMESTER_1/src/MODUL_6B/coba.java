/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODUL_6B;

/**
 *
 * @author ACER
 */
public class coba {
       public static void main(String[] args) {
            int  bilangan = 1;
	    while ( bilangan < 16 ) {
		System.out.println(bilangan);
		bilangan = bilangan + 1;
		}
	    }
	}

