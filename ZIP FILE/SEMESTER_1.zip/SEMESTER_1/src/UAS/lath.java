package UAS;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ACER
 */
public class lath {
lath(){}
void jalan_maju(){
    System.out.println("maju");
}
public static void main (String[] args){
    lath sedan = new lath();
    sedan.jalan_maju();
}
}
        


        
