/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqlconnection;

import java.sql.*;
/**
 *
 * @author Tak Bertuan
 */
public class Connect {
    private final String jdbcURL = "jdbc:mysql://localhost:3306/keluhan";
    private final String user = "root";
    private final String password = "205314096"; //ganti
    Connection conn;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    
    public Connect(){}

    public void setConn(Connection conn) {
        this.conn = conn;
    }

    public void setStmt(Statement stmt) {
        this.stmt = stmt;
    }

    public void setPstmt(String statement) {
        try{
            this.pstmt = this.conn.prepareStatement(statement);
        }catch(SQLException e){
            System.err.println(e.getMessage());
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
    }

    public void setRs(ResultSet rs) {
        this.rs = rs;
    }

    public Connection getConn() {
        return conn;
    }

    public Statement getStmt() {
        return stmt;
    }

    public PreparedStatement getPstmt() {
        return pstmt;
    }

    public ResultSet getRs() {
        return rs;
    }
    
    public void connect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connecting to MySQL server..");
            conn = DriverManager.getConnection(jdbcURL, user, password);
            System.out.println("Connection established!");
        } catch (Exception e) {
            System.err.println("An error occured while connecting!");
            System.err.println(e.getMessage());
        }
    }
    
    public void close(){
        try{
            conn.close();
            System.out.println("Disconnected!");
        } catch(SQLException e){
            System.err.println(e.getMessage());
        }
    }
}
