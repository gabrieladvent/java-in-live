/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UTS;
import UTS.Telepon;
import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class dtTelepon {
    ArrayList <Telepon> teleponList = new ArrayList<> ();

public dtTelepon (){
    teleponList.clear();
}
public static void cari (Telepon data){}
public static void hapus (Telepon data){}
public static void isi (Telepon data){}
}
