/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author ACER
 */
public class Pembelian {
     private String namaBarang;
    private int stokBarang;
    private int jmlhBarang; //jumlah barang yang dibeli
    private int hargaBarang;
    private Pelanggan[] costumer;

    public Pembelian(){}

    public int hitungTotalHarga(){
        System.out.println("");
        return 0;
    }
    
    public int hargaTotSetelahDiskon(){
        System.out.println("");
        return 0;
    }
    public String getNamaBarang() {
        return namaBarang;
    }
    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }
    public int getStokBarang() {
        return stokBarang;
    }
    public void setStokBarang(int stokBarang) {
        this.stokBarang = stokBarang;
    }
    public int getHargaBarang() {
        return hargaBarang;
    }
    public void setHargaBarang(int hargaBarang) {
        this.hargaBarang = hargaBarang;
    }
    public int getJmlhBarang() {
        return jmlhBarang;
    }
    public void setJmlhBarang(int jmlhBarang) {
        this.jmlhBarang = jmlhBarang;
    } 
    public Pelanggan[] getCostumer() {
        return costumer;
    }
    public void setCostumer(Pelanggan akun) {
        this.costumer = costumer;
    }
  

}
