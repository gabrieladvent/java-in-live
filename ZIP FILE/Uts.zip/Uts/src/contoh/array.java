/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contoh;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class array {
    public static void main(String[] args) {
           Scanner in = new Scanner(System.in);
        
        int n;
        System.out.println("\t\t\tSMA NUSA BANGSA");
        System.out.println("===============================================================================");
        System.out.print("Masukan jumlah siswa : ");
        n = in.nextInt();
        System.out.println();
        
        int [] nim = new int [n];
        String [] nama = new String [n];
        double [] us1 = new double [n];
        double [] us2 = new double [n];
        double [] uas = new double [n];
        double [] total  = new double [n];
        char [] akhir  = new char [n];

        System.out.println("No.\t"+"Nama\t\t"+"NIM\t\t"+"US1\t"+"US2\t"+"UAS\t"+"Total\t"+"Final");
        System.out.println("-------------------------------------------------------------------------------");
        
        for (int i = 0; i < n ; i++) {
            
            int a = i + 1;
            System.out.print(a+".");
            nama[i] = in.next();
            System.out.print("\t\t");
            nim[i] = in.nextInt();
            System.out.print("\t\t");
            us1[i] = in.nextDouble();
            System.out.print("\t");
            us2[i] = in.nextDouble();
            System.out.print("\t");
            uas[i] = in.nextDouble();
            System.out.print("\t\t");
            
            total[i] = hitungtotal(us1[i],us2[i], uas[i]);
            if (total[i] >= 80) {
                akhir[i] = 'A';
            }else if (65 <= total[i] && total[i] < 80 ) {
                akhir[i] = 'B';
            }else if (55 <= total[i] && total[i] < 65) {
                akhir[i] = 'C';
            }else if (50 <= total[i] && total[i] < 55) {
                akhir[i] = 'D';
            }else {
                akhir[i] = 'E';
            }
            System.out.print(total[i]+"\t");
            System.out.print(akhir[i]);
            System.out.println();
        }
            System.out.println("===============================================================================");
            System.out.println("\t\t\tURUTAN NILAI SISWA");
            System.out.println("No.\t"+"Nama\t\t"+"NIM\t\t"+"US1\t"+"US2\t"+"UAS\t"+"Total\t"+"Final");
            System.out.println("-------------------------------------------------------------------------------");
            for (int a = 0; a < n - 1; a++) {
                for (int j = 0; j < n - (a + 1); j++) {
                    if(total[j] < total[j + 1]){
                        double swap = total[j];
                        total[j] = total[j+1];
                        total [j+1] = swap;
                 
                        int ganti = nim [j+1];
                        nim[j] = nim[j+1];
                        nim[j+1] = ganti;
   
                        double pindah = us1 [j+1];
                        us1[j] = us1[j+1];
                        us1[j+1] = pindah;
           
                        double baru = us2 [j+1];
                        us2[j] = us2[j+1];
                        us2[j+1] = baru;
               
                         double flip = uas [j+1];
                        uas[j] = uas[j+1];
                        uas[j+1] = flip;
                    
                        String tukar = nama [j+1];
                        nama[j] = nama[j+1];
                        nama [j+1] = tukar;
                        
                        char finale = akhir [j+1];
                        akhir[j] = akhir[j+1];
                        akhir [j+1] = finale;
                } 
            }
        }
        for (int i = 0; i < n; i++) {
            int no = i +1;
                    System.out.print(no+".\t"+nama[i]+"\t\t"+nim[i]+"\t"+us1[i]+"\t"+us2[i]+"\t"+uas[i]+"\t"+total[i]+"\t"+akhir[i]);
                    System.out.println();   
        }
            System.out.println("===============================================================================");
    }
    static double hitungtotal(double us1, double us2, double uas){
        double totalNil = 0.3 * us1 + 0.3 * us2 + 0.4 * uas;
        return totalNil;    
    } 
    }

