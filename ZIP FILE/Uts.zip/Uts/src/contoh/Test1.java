/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contoh;

/**
 *
 * @author ACER
 */
public class Test1 {
    public static void main(String[] args) {
        SmartPhone phone1 = new SmartPhone("0811111");
        SmartPhone phone2 = new SmartPhone("0811112");
        
        phone1.sendShortMessage("hello kitty", phone2);
        phone2.sendShortMessage("hello too", phone2);
        
        for(int i =0; i < phone2.getNumberOfMessage(); i++){
            System.out.println(phone2.getMessageList()[i]);
        }
    }
}
