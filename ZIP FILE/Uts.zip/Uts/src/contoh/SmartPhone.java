/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contoh;

/**
 *
 * @author ACER
 */
public class SmartPhone extends Computer implements Phone {
    public int maksimumNumberOfMessage =10;
    private String phoneNumber;
    private ShortMessage messageList[] = new ShortMessage[maksimumNumberOfMessage];
    private int numberOfMessage =0;
    
    public SmartPhone(){}
    
    public SmartPhone(String processor, String memory, String operatingSystem,String phoneNumber){
        super(processor,memory,operatingSystem);
        this.phoneNumber = phoneNumber;
    }
    public SmartPhone(String phoneNumber){
        this.phoneNumber = phoneNumber;
    }
    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    @Override
    public void sendShortMessage(String message, Phone receiver){
        ShortMessage sms = new ShortMessage (message,this);
        receiver.reiceveShortMessage(sms);
    }
    public void receiverShortMessage(ShortMessage message){
        messageList[getNumberOfMessage()] = message;
        if(getNumberOfMessage() < maksimumNumberOfMessage){
            numberOfMessage++;
        }else{
            numberOfMessage =0;
        }
    }
    public int getNumberOfMessage() {
        return numberOfMessage;
    }
    public ShortMessage[] getMessageList() {
        return messageList;
    }
    @Override
    public String toString(){
        return super.toString()+","+phoneNumber;
    }

   
    
}
