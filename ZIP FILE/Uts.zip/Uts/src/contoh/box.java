/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contoh;

/**
 *
 * @author ACER
 */
public class box {
    int panjang;
    int lebar;
    int tinggi;
    int volume;
   void volume(int panjang, int lebar, int tinggi){
       volume = panjang*lebar*tinggi;
   }
}

class main{
    public static void main(String[] args) {
        box obj = new box();
        obj.panjang =1;
        obj.lebar =5;
        obj.tinggi =5;
        obj.volume(3,2,1);
        System.out.println(obj.volume);
                
    }
}