/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SoalF;


/**
 *
 * @author ACER
 */
public class Perjanjian {
    //deklarasi variabel private
    private String kode;
    private String namaPelanggan;
    private String jenisMobil;
    private int biaya;
    
    public Perjanjian(String n, int b){ //membuat konstruktor bernama Perjanjian dengan parameter String, int
        this.namaPelanggan = n;
        this.biaya = b;
    }
    public Perjanjian(){ //membuat konstruktor bernama Perjanjian tanpa parameter
        this.namaPelanggan = "n";
        this.biaya = 0;
    }
//membuat method getter setter
    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public String getJenisMobil() {
        return jenisMobil;
    }

    public void setJenisMobil(String jenisMobil) {
        this.jenisMobil = jenisMobil;
    }

    public int getBiaya() {
        return biaya;
    }

    public void setBiaya(int biaya) {
        this.biaya = biaya;
    }
    
} 

