/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SoalF;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class MainService {
    //Nama: Kezia Megumi Manabung 
    //NIM: 215314196
    public static void main(String[] args) { //membuat kelas main method
        Scanner input = new Scanner (System.in); // membuat input Scanner dari keyboard
        String namaP, kode, jenis; // Deklarasi variabel bernama namaP, kode, jenis bertipe String
        int jum, biaya, total = 0; // Deklarasi variabel bernama jum, biaya, total dengan nilai 0 bertipe integer
        System.out.println("===SERVICES MOBIL==="); //Cetak tulisan "===SERVICES MOBIL==="
        Perjanjian d; // Membuat objek baru bernama d bertipe Perjanjian
        KantorLayanan data = new KantorLayanan("Service Mobil Manado"); // Membuat objek data bertipe DataLayanan dengan parameter bertipe String
        System.out.println("Nama Kantor Layanan \t: "+data.getNama());// Cetak tulisan "Nama Kantor Layanan: "
        System.out.print("Kode Kantor \t\t: "); // Cetak tulisan "Kode Kantor: "
        data.setKode(input.next()); //baca input dari keyboard bertipe String lalu disimpan ke variabel setKode dari kelas KantorLayanan
        System.out.print("Lokasi \t\t: "); // Cetak tulisan "Lokasi: "
        data.setLokasi(input.next()); //baca input dari keyboard bertipe String lalu disimpan ke variabel setLokasi dari kelas KantorLayanan
        System.out.print("Berapa perjanjian yang akan dibuat? "); // Cetak tulisan "Berapa perjanjian yang akan dibuat? "
        jum = input.nextInt(); // baca input nilai melalui keyboard lalu simpan ke variabel jum
        for(int i = 1; i <= jum; i++){ //membuat loop for(deklarasi variabel i bertipe integer = 1; i kurang dari sama dengan jum; inkremen i)
            System.out.print("Kode \t\t: "); // Cetak tulisan "Kode: "
            kode = input.next(); // baca input dari keyboard bertipe String lalu disimpan ke variabel kode
            System.out.print("Nama Pelanggan \t: "); // Cetak tulisan "Nama Pelanggan: "
            namaP = input.next(); //baca input dari keyboard bertipe String lalu disimpan ke variabel namaP
            System.out.print("Jenis Mobil \t: "); // Cetak tulisan "Jenis Mobil: "
            jenis = input.next(); //baca input dari keyboard bertipe String lalu disimpan ke variabel jenis
            System.out.print("Biaya \t\t: "); // Cetak tulisan "Biaya: "
            biaya = input.nextInt(); //baca input dari keyboard bertipe integer lalu disimpan ke variabel biaya
            System.out.println(); // Buat baris baru
            d = new Perjanjian(); // membuat objer perjanjian bernama d
            d.setKode(kode); //memanggil method setKode dari objek d lalu mengeset nilai kode
            d.setNamaPelanggan(namaP);  //memanggil method setNamaPelanggan dari objek d lalu mengeset nilai namaP
            d.setJenisMobil(jenis);  //memanggil method setJenisMobil dari objek d lalu mengeset nilai jenis
            d.setBiaya(biaya);  //memanggil method setBiaya dari objek d lalu mengeset nilai biaya
            data.setDaftarPerjanjian(d);  //memanggil method setDaftarPerjanjian dari objek data lalu mengeset nilai d
        }
        System.out.println("Kantor Layanan \t: "+data.getNama()); //cetak tulisan "Kantor Layanan :" lalu menampilkan hasil getNama() dari objek data
        System.out.println("Perjanjian: ");//cetak tulisan "Perjanjian:"
        for(int i = 0; i < data.getJlhPerjanjian(); i++){//membuar for loop
            //mecetak tulisan dibawah lalu menampilkan hasil dari objek data dan method getter yang dipanggil
            System.out.println((i+1)+". Nama\t\t: "+data.getDaftarPerjanjian(i).getNamaPelanggan());
            System.out.println("   Kode\t\t:"+data.getDaftarPerjanjian(i).getKode());
            System.out.println("   Jenis Mobil\t:"+data.getDaftarPerjanjian(i).getJenisMobil());
            System.out.println("   Biaya\t:"+data.getDaftarPerjanjian(i).getBiaya());
            total = total+data.getDaftarPerjanjian(i).getBiaya();//menghitung nilai total
        }
        System.out.println("Total Uang\t: "+total);//cetak tulisan "Total Uang : " lalu menampilkan hasil variabel totl

    }
}
