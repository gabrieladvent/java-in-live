/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SoalF;

/**
 *
 * @author ACER
 */
public class KantorLayanan {
    //Nama: Kezia Megumi Manabung
    //NIM: 215314196
    //deklarasi variabel
    public static final int MAX_SHIFT = 10;
    private String kode;
    private String nama;
    private String lokasi;
    private Perjanjian[] daftarPerjanjian;
    private int jlhPerjanjian;
    
    public KantorLayanan(){}//membuat konstruktor bernama KantorLayanan tanpa parameter
    
    public KantorLayanan(String nama){ //membuat konstuktor bernama KantorLayanan dengan parameter bertipe String
        this.nama = nama; //mengisi nama dengan nama
        daftarPerjanjian = new Perjanjian[MAX_SHIFT];
        jlhPerjanjian = 0;
    }
//membuat method getter dan setter
    public String getKode() {
        return kode;
    }

    public void setKode(String kode) {
        this.kode = kode;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public Perjanjian getDaftarPerjanjian(int index) {
        return daftarPerjanjian[index];
    }

    public void setDaftarPerjanjian(Perjanjian daftarPerjanjian) {
        this.daftarPerjanjian[this.jlhPerjanjian] = daftarPerjanjian;
        this.jlhPerjanjian++;
    }

    public int getJlhPerjanjian() {
        return jlhPerjanjian;
    }

    public void setJlhPerjanjian(int jlhPerjanjian) {
        this.jlhPerjanjian = jlhPerjanjian;
    }
}
    
    

