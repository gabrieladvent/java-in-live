/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SoalF;

/**
 *
 * @author ACER
 */
public class Acces {
   private int a;
   public Acces(){
       a =10;
   }
   public void call(Acces sg){
       sg.a= sg.a+10;
   }
    public static void main(String[] args) {
        Acces eg = new Acces();
        System.out.println("Sebelum: "+eg.a);
        eg.call(eg);
        System.out.println("Setelah: "+eg.a);
    }
}

