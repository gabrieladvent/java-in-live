/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpus;

/**
 *
 * @author hp
 */
public class Koleksi {
    private String IDKoleksi;
    private String Judul;
    private String Penerbit;
    private String Status;

    public String getIDKoleksi() {
        return IDKoleksi;
    }

    public void setIDKoleksi(String IDKoleksi) {
        this.IDKoleksi = IDKoleksi;
    }

    public String getJudul() {
        return Judul;
    }

    public void setJudul(String Judul) {
        this.Judul = Judul;
    }

    public String getPenerbit() {
        return Penerbit;
    }

    public void setPenerbit(String Penerbit) {
        this.Penerbit = Penerbit;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

  

}
