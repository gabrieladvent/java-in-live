
package perpus;


public class Transaksi {
    private String IDTransaksi;
    private String TglPinjam;
    private String TglKembali;
    private String Denda;
    private String Koleksi;
    private String Peminjam ;

    public String getIDTransaksi() {
        return IDTransaksi;
    }

    public void setIDTransaksi(String IDTransaksi) {
        this.IDTransaksi = IDTransaksi;
    }

    public String getTglPinjam() {
        return TglPinjam;
    }

    public void setTglPinjam(String TglPinjam) {
        this.TglPinjam = TglPinjam;
    }

    public String getTglKembali() {
        return TglKembali;
    }

    public void setTglKembali(String TglKembali) {
        this.TglKembali = TglKembali;
    }

    public String getDenda() {
        return Denda;
    }

    public void setDenda(String Denda) {
        this.Denda = Denda;
    }

    public String getKoleksi() {
        return Koleksi;
    }

    public void setKoleksi(String Koleksi) {
        this.Koleksi = Koleksi;
    }

    public String getPeminjam() {
        return Peminjam;
    }

    public void setPeminjam(String Peminjam) {
        this.Peminjam = Peminjam;
    }
    
    
    
    
}
