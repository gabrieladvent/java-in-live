package PunyaCatrien;
public class Main {
    public static void main(String[] args) {
        InputAge2 frame = new InputAge2();
        frame.setVisible(true);
    }
}
