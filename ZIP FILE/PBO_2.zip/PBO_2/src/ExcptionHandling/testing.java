/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ExcptionHandling;

/**
 *
 * @author ACER
 */
public class testing {
    public static void main(String[] args) {
        InputAge2 frame = new InputAge2();
        frame.setVisible(true);
    }
}
