package Main;

import RumahSakit.Obat;
import RumahSakit.Pengantri;
import java.util.Scanner;
import NewStack.LinkedList_Objek;
import Queue.objekDinamis;

public class ApotekMain {
    public static void main(String[] args) {
        boolean isActive = true;
        int n;
        int antri = 0;
        Pengantri pengantri;
        Obat obat;
        
        LinkedList_Objek listAntri = new LinkedList_Objek();
        LinkedList_Objek listObat = new LinkedList_Objek();
        objekDinamis queue = new objekDinamis();
        
        Scanner inputString = new Scanner(System.in);
        Scanner input = new Scanner(System.in);
        
        while(isActive){
            System.out.println("1. Tambahkan Obat");
            System.out.println("2. Tampilkan Daftar Obat");
            System.out.println("3. Tambahkan Customer");
            System.out.println("4. Tampilkan Antrian Customer");
            System.out.println("5. Memanggil Customer");
            System.out.println("6. Tutup");
            do{
                System.out.print("Input: ");
                n = input.nextInt();
            }while(n < 1 || n > 6);
            switch(n){
                case 1 -> {
                    System.out.println();
                    String wujud;
                    
                    System.out.print("Nama obat: ");
                    String namaObat = inputString.nextLine();
                    do{
                        System.out.print("Bentuk obat: (Padat/Cair) ");
                        wujud = input.next();
                    } while(!wujud.equalsIgnoreCase("Padat") && !wujud.equalsIgnoreCase("Cair"));
                    obat = new Obat(namaObat, wujud);
                    listObat.addLast(obat);
                    System.out.println("Obat berhasil ditambahkan!\n");
                }
                case 2 -> {
                    if (listObat.isEmpty()){
                        System.out.println();
                        System.err.println("Daftar obat kosong!\n");
                    } else{
                    System.out.println();
                    System.out.println(listObat);
                    }
                }
                case 3 -> {
                    if(listObat.isEmpty()){
                        System.out.println();
                        System.err.println("Data obat kosong!\n");
                    } else {
                        pengantri = new Pengantri();
                        System.out.println();
                        System.out.print("Nama Customer: ");
                        String namaPenerima = inputString.nextLine();
                        System.out.print("Jumlah Obat yang akan Diambil: ");
                        int jumlah = input.nextInt();
                        System.out.println("List obat yang tersedia:");
                        System.out.println(listObat);
                        for(int i = 0; i < jumlah; i++){
                            int pilih;
                            int pemakaian;
                            double dosis;
                            do{
                                System.out.print("Pilih obat: ");
                                pilih = input.nextInt();
                            }while(pilih > listObat.size() || pilih < 1);
                            Obat med = (Obat) listObat.grabNode(pilih);
                            pengantri.addList(med);
                            System.out.println("Obat ditambahkan!");
                            if(med.getWujud().equalsIgnoreCase("CAIR")){
                                System.out.print("Dosis (ml): ");
                            } else {
                                System.out.print("Dosis (tablet): ");
                            }
                            dosis = input.nextDouble();
                            med.setDosis(dosis);
                            System.out.print("Pemakaian (dalam sehari): ");
                            pemakaian = input.nextInt();
                            med.setJmlhPemakaian(pemakaian);
                            String konsum;
                            do{
                                System.out.print("Dikonsumsi setelah makan? (Ya/Tidak) ");
                                konsum = input.next();
                            }while(!konsum.equalsIgnoreCase("Tidak") && !konsum.equalsIgnoreCase("Ya"));
                            if(konsum.equalsIgnoreCase("Tidak")){
                                med.setIsSesudahMakan(false);
                            } else {
                                med.setIsSesudahMakan(true);
                            }
                        }
                        pengantri.setNamaPenerima(namaPenerima);
                        pengantri.setJumlahObat(jumlah);
                        pengantri.setAngkaAntrian(++antri);
                        System.out.println();
                        System.out.println("Berhasil ditambahkan!");
                        
                        pengantri.cetak();
                        
                        listAntri.addLast(pengantri);
                        queue.enqueue(pengantri);
                        System.out.println("\nDitambahkan pada antrian");
                    }
                }
                case 4 -> {
                    if(!queue.isEmpty()){
                        System.out.println();
                        System.out.println("Daftar antrian:");
                        System.out.println(queue);
                    }
                    else System.err.println("Antrian masih kosong");
                }
                case 5 -> {
                    if(!queue.isEmpty()){
                        System.out.println("Customer nomor " + ((Pengantri)listAntri.grabNode(1)).getAngkaAntrian() + " dipanggil");
                        queue.dequeue();
                        listAntri.removeFirst();
                    }
                    else System.err.println("Antrian kosong");
                }
                case 6 -> {
                    isActive = false;
                }
            }
        }
    }
}