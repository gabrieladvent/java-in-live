/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Queue;

import NewStack.LinkedList_Objek;

/**
 *
 * @author Tak Bertuan
 */
public class objekDinamis {
    LinkedList_Objek antrian;
public objekDinamis(LinkedList_Objek antrian) {
        this.antrian = antrian;
}
public objekDinamis (){
        antrian = new LinkedList_Objek();
}
public void enqueue (Object data){
        antrian.addLast(data);
}
public Object dequeue(){
        return antrian.removeFirst();
}
public int Size() {
        return antrian.size();
}
public boolean isEmpty() {
        if (antrian.size() == -1){
            return true;
        } 
        return false;
}
    @Override
    public String toString(){
        return antrian.toString();
}
}