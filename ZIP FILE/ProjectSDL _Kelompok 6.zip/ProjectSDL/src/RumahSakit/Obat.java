package RumahSakit;

public class Obat {
    private String namaObat;
    private String wujud;
    private double dosis;
    private int jmlhPemakaian;
    private boolean isSesudahMakan;
    private double harga;
    
    public Obat(){};
    
    public Obat(String namaObat, String wujud) {
        this.namaObat = namaObat;
        this.wujud = wujud;
    }

    public String getNamaObat() {
        return namaObat;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public void setWujud(String wujud) {
        this.wujud = wujud;
    }

    public double getDosis() {
        return dosis;
    }

    public void setDosis(double dosis) {
        this.dosis = dosis;
    }

    public int getJmlhPemakaian() {
        return jmlhPemakaian;
    }

    public void setJmlhPemakaian(int jmlhPemakaian) {
        this.jmlhPemakaian = jmlhPemakaian;
    }

    public boolean isIsSesudahMakan() {
        return isSesudahMakan;
    }

    public void setIsSesudahMakan(boolean isSesudahMakan) {
        this.isSesudahMakan = isSesudahMakan;
    }

    public String getWujud() {
        return wujud;
    }
    
    public double hargaObat(){
        if(wujud.equalsIgnoreCase("Padat")){
            harga = 5000 * dosis; 
        } else {
            harga = 250 * dosis; //Jika obat cair dan 250/ml
        }
        return harga;
    }
    
    @Override
    public String toString(){
        return namaObat + " | " +wujud.toUpperCase();
    }
}
