package RumahSakit;

import NewStack.LinkedList_Objek;

public class Pengantri {
    private String namaPenerima;
    private int jumlahObat;
    private int angkaAntrian;
    private LinkedList_Objek list;
    private Obat obat;
    private double harga;

    public Pengantri() {
        this.list = new LinkedList_Objek();
    }

    public String getNamaPenerima() {
        return namaPenerima;
    }
 
    public void setNamaPenerima(String namaPenerima) {
        this.namaPenerima = namaPenerima;
    }

    public LinkedList_Objek getList() {
        return list;
    }

    public void addList(Obat obat) {
        this.list.addLast(obat);
    }

    public int getJumlahObat() {
        return jumlahObat;
    }

    public void setJumlahObat(int jumlahObat) {
        this.jumlahObat = jumlahObat;
    }

    public int getAngkaAntrian() {
        return angkaAntrian;
    }

    public void setAngkaAntrian(int angkaAntrian) {
        this.angkaAntrian = angkaAntrian;
    }
    
    public void cetak(){
        System.out.println("Nama Customer\t: " + getNamaPenerima());
        System.out.println("Jumlah Obat\t: " + getJumlahObat());
        System.out.println("Obat yang dipesan beserta detailnya: ");
        System.out.println();
        System.out.println("Obat\tBentuk\tDosis\tPetunjuk Pemakaian\tHarga");
        System.out.println("--------------------------------------------------");
        for(int i = 1; i <= getList().size(); i++){
            Obat med = (Obat) getList().grabNode(i);
            System.out.print(med.getNamaObat() + "\t" + med.getWujud() + "\t");
            if(med.getWujud().equalsIgnoreCase("CAIR")){
                System.out.print(med.getDosis() + " ml\t");
            } else {
                System.out.print(med.getDosis() + " tablet\t");
            }
            System.out.print("Pemakaian 1x" + med.getJmlhPemakaian() + " ");
            if(med.isIsSesudahMakan()){
                System.out.print("sesudah makan\t");
            } else {
                System.out.print("sebelum makan\t");
            }
            System.out.println(med.hargaObat());
        }
        System.out.println("--------------------------------------------------");
        System.out.println("Harga total obat: " + harga() + "\n");
        System.out.println("Antrian nomor: " + getAngkaAntrian());
    }
    
    @Override
    public String toString(){
        return getNamaPenerima() + "\t" + " Nomor Antrian: " + getAngkaAntrian();
    }
    
    public double harga() {
        for(int i = 1; i <= list.size(); i++){
            harga += ((Obat)list.grabNode(i)).hargaObat();
        }
        return harga;
    }

}
