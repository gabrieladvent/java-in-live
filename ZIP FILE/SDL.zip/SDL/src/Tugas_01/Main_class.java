/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tugas_01;

/**
 *
 * @author ACER
 */
public class Main_class {
    public static void main(String[] args) {
        int [] data = {20, 50, 32, 21, 44};
        Larik.Cetak(data);
    }
}
