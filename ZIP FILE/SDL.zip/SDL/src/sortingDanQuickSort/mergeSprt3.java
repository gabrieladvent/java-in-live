/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingDanQuickSort;

/**
 *
 * @author ACER
 */
public class mergeSprt3 {
    public static void mergeSort(int [] data, int awal, int mid, int akhir){
        if (awal < akhir){
            
        }
    }
}
